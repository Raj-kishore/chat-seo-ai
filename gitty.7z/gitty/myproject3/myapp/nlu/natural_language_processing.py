# Natural Language Processing
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Importing the dataset
dataset = pd.read_csv('D:\\myChatbot\\myproject3\\myapp\\nlu\\master_data.tsv', delimiter = '\t', quoting = 3, error_bad_lines=False)

dataset_total_rows = len(dataset)



# Cleaning the texts
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer


import  datetime
def Logger(msg):
    # Log an error message
    with open("D:\\myChatbot\\logger.txt", "a") as myfile:
        myfile.write(str(datetime.datetime.now()) +" "+ str(msg) + "\n")
def takeInput(data):
    corpus = []



    for i in range(0, dataset_total_rows):
        print(dataset['sentance'][i])
        review = re.sub('[^a-zA-Z]', ' ', dataset['sentance'][i])
        review = review.lower()
        review = review.split()
        ps = PorterStemmer()
        review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
        review = ' '.join(review)
        corpus.append(review)
        print(review)


    new_text_by_user = data
    review2 = re.sub('[^a-zA-Z]', ' ', new_text_by_user)
    review2 = review2.lower()
    review2 = review2.split()
    ps2 = PorterStemmer()
    review2 = [ps2.stem(word) for word in review2 if not word in set(stopwords.words('english'))]
    review2 = ' '.join(review2)
    corpus.append(review2)


    Logger("Corpus length "+ str(len(corpus)))



    # Creating the Bag of Words model
    from sklearn.feature_extraction.text import CountVectorizer
    cv = CountVectorizer(max_features = 1500)
    X = cv.fit_transform(corpus).toarray()


    X_formatted = np.array([X[-1,:]])



    y = dataset.iloc[:, 1].values




    #categorical data
    from sklearn import preprocessing
    le = preprocessing.LabelEncoder()
    le.fit(y)
    y = le.transform(y)


    X_except_last_row = X[:-1, :]
    # Splitting the dataset into the Training set and Test set
    #from sklearn.model_selection import train_test_split
    #X_train, X_test, y_train, y_test = train_test_split(X_except_last_row, y, test_size = 0.20, random_state = 0)
    # Fitting Naive Bayes to the Training set


    from sklearn.naive_bayes import GaussianNB
    classifier = GaussianNB()
    classifier.fit(X_except_last_row, y)

    import pickle
    # save the classifier
    with open('my_dumped_classifier.pkl', 'wb') as fid:
        pickle.dump(classifier, fid)


    # load it again
    with open('my_dumped_classifier.pkl', 'rb') as fid:
        classifier_loaded = pickle.load(fid)

    # Predicting the Test set results
    y_pred = classifier_loaded.predict(X_formatted)
    # Making the Confusion Matrix
    #from sklearn.metrics import confusion_matrix
    #cm = confusion_matrix(y_test, y_pred)
    return  y_pred

