# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 17:14:33 2019

@author: ramahara
"""
# Natural Language Processing
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Importing the dataset
dataset = pd.read_csv('E:\\python\\jangoD invisible\\model-test\\intent_data.tsv', delimiter = '\t', quoting = 3, error_bad_lines=False)
dataset_total_rows = len(dataset)
# Cleaning the texts
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
corpus = []
for i in range(0, dataset_total_rows):
    print(dataset['sentance'][i])
    review = re.sub('[^a-zA-Z]', ' ', dataset['sentance'][i])
    review = review.lower()
    review = review.split()
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
    review = ' '.join(review)
    corpus.append(review)
    

'''start'''
import nltk
from nltk.tokenize import RegexpTokenizer

TOKENIZER = RegexpTokenizer('(?u)\W+|\$[\d\.]+|\S+')

from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
#nltk.download('punkt')
#nltk.download('averaged_perceptron_tagger')
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

ex = "I am called, Raj"

def preprocess(sent):
    sent =  nltk.word_tokenize(sent)
    #sent =  TOKENIZER.tokenize(sent)
    sent = nltk.pos_tag(sent)
    return sent

sent = preprocess(ex)

'''
for x in range(len(sent)):
    if sent[x][1] == "NNP":      
        if sent[x][0] != " ":
            ex = ex.replace(sent[x][0],"nnp")
    else:
        pass
'''
review2 = re.sub('[^a-zA-Z]', ' ', ex)
review2 = review2.lower()
review2 = review2.split()
ps = PorterStemmer()
review2 = [ps.stem(word) for word in review2 if not word in set(stopwords.words('english'))]
review2 = ' '.join(review2)    
        
'''end'''

corpus.append(review2)



# Creating the Bag of Words model
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(max_features = 1500)
X = cv.fit_transform(corpus).toarray()
X_without_last_row = X[:-1,:]

X_last_row = np.array([X[-1,:]])

y = dataset.iloc[:, 1].values
#categorical data
from sklearn import preprocessing
le = preprocessing.LabelEncoder()
le.fit(y)
y = le.transform(y)

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_without_last_row, y, test_size = 0.20, random_state = 0)
# Fitting Naive Bayes to the Training set


from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_without_last_row, y)


# Predicting the Test set results
y_pred1 = classifier.predict(X_test)
y_pred2 = classifier.predict_log_proba(X_test)
y_pred3 = classifier.predict_proba(X_test)


# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred1)
y_pred4 = classifier.predict(X_last_row)



'''
Create a list of locations list that will identify as location entity and the rest nnp as name.
'''
''' total 35 tags
CC coordinating conjunction
CD cardinal digit
DT determiner
EX existential there (like: “there is” … think of it like “there exists”)
FW foreign word
IN preposition/subordinating conjunction
JJ adjective ‘big’
JJR adjective, comparative ‘bigger’
JJS adjective, superlative ‘biggest’
LS list marker 1)
MD modal could, will
NN noun, singular ‘desk’
NNS noun plural ‘desks’
NNP proper noun, singular ‘Harrison’
NNPS proper noun, plural ‘Americans’
PDT predeterminer ‘all the kids’
POS possessive ending parent‘s
PRP personal pronoun I, he, she
PRP$ possessive pronoun my, his, hers
RB adverb very, silently,
RBR adverb, comparative better
RBS adverb, superlative best
RP particle give up
TO to go ‘to‘ the store.
UH interjection errrrrrrrm
VB verb, base form take
VBD verb, past tense took
VBG verb, gerund/present participle taking
VBN verb, past participle taken
VBP verb, sing. present, non-3d take
VBZ verb, 3rd person sing. present takes
WDT wh-determiner which
WP wh-pronoun who, what
WP$ possessive wh-pronoun whose
WRB wh-abverb where, when

'''